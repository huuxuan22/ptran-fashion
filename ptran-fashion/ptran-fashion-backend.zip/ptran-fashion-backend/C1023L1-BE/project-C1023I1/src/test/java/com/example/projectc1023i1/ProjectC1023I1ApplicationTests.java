package com.example.projectc1023i1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectC1023I1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
